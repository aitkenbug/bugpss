typedef unsigned long long Bcd;

Bcd sumaBcd(Bcd x, Bcd y);
